package days12;

public class Time {

}
