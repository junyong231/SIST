package days12;
//좌표를 다루는 클래스

public class Point {
	
	
	//field 필드
	public int x = 0;
	public int y = 0;
	public int [] m;
	
	//method
	public void dispPoint() {
		System.out.printf("> x=%d, y=%d",x,y);
	}
	
}
