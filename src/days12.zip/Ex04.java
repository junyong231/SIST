package days12;

import java.util.Random;
import java.util.Scanner;

/**
 * @author JUNYONG
 * @Date 2024. 7. 16.=오후 2:22:20
 * @subject
 * @content
 *
 */
public class Ex04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();
		//얘네도 객체 생성해서 사용가능한 거였음 ㅇㅇ
		
		// System s = new System(); 불가
		
		//Member n = new Member;
		
	}//main

}//class
