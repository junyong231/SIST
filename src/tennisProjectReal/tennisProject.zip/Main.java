package tennisProjectReal.tennisProject;

public class Main {

	public static void main(String[] args) {
		
		GameManager gm = new GameManager();
		gm.startGame();
		
	}

}


